var struct_kinematic_character_controller_1_1_hit_stability_report =
[
    [ "DistanceFromLedge", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a7c34849c554849aca99c8754d694074f", null ],
    [ "InnerNormal", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a377d0d40e955bc00133ba2ddf7ffe4fa", null ],
    [ "IsOnEmptySideOfLedge", "struct_kinematic_character_controller_1_1_hit_stability_report.html#ada77a04aa9163cd13c2dc26d98353a28", null ],
    [ "IsStable", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a99b11bacec731700fc4bbeb49e9dd6e6", null ],
    [ "LedgeDetected", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a288631df92c4cca9a63319d039b25819", null ],
    [ "LedgeFacingDirection", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a36fc72069aab9413247135b0235f697d", null ],
    [ "LedgeGroundNormal", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a021f7795811ed6a13f3f00820fbeacb9", null ],
    [ "LedgeRightDirection", "struct_kinematic_character_controller_1_1_hit_stability_report.html#aa0a6ba8dcc21331c86cebf39d3ea1afc", null ],
    [ "OuterNormal", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a678f760b84634480770dcd715964db7d", null ],
    [ "SteppedCollider", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a1ad58fdbd854f274f83d8f4f5c902f18", null ],
    [ "ValidStepDetected", "struct_kinematic_character_controller_1_1_hit_stability_report.html#a4ae06accfa716228f62fc80f763c2f2c", null ]
];