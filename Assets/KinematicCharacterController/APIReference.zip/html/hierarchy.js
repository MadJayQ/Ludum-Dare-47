var hierarchy =
[
    [ "KinematicCharacterController.CharacterGroundingReport", "struct_kinematic_character_controller_1_1_character_grounding_report.html", null ],
    [ "KinematicCharacterController.CharacterTransientGroundingReport", "struct_kinematic_character_controller_1_1_character_transient_grounding_report.html", null ],
    [ "KinematicCharacterController.HitStabilityReport", "struct_kinematic_character_controller_1_1_hit_stability_report.html", null ],
    [ "KinematicCharacterController.KinematicCharacterMotorState", "struct_kinematic_character_controller_1_1_kinematic_character_motor_state.html", null ],
    [ "MonoBehaviour", null, [
      [ "KinematicCharacterController.BaseCharacterController", "class_kinematic_character_controller_1_1_base_character_controller.html", null ],
      [ "KinematicCharacterController.BaseMoverController", "class_kinematic_character_controller_1_1_base_mover_controller.html", null ],
      [ "KinematicCharacterController.KinematicCharacterMotor", "class_kinematic_character_controller_1_1_kinematic_character_motor.html", null ],
      [ "KinematicCharacterController.KinematicCharacterSystem", "class_kinematic_character_controller_1_1_kinematic_character_system.html", null ],
      [ "KinematicCharacterController.PhysicsMover", "class_kinematic_character_controller_1_1_physics_mover.html", null ]
    ] ],
    [ "KinematicCharacterController.OverlapResult", "struct_kinematic_character_controller_1_1_overlap_result.html", null ],
    [ "KinematicCharacterController.PhysicsMoverState", "struct_kinematic_character_controller_1_1_physics_mover_state.html", null ],
    [ "PropertyAttribute", null, [
      [ "KinematicCharacterController.ReadOnlyAttribute", "class_kinematic_character_controller_1_1_read_only_attribute.html", null ]
    ] ],
    [ "KinematicCharacterController.RigidbodyProjectionHit", "struct_kinematic_character_controller_1_1_rigidbody_projection_hit.html", null ]
];